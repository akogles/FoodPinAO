//
//  UINavigationController+Ext.swift
//  FoodPin
//
//  Created by Alan Ogles on 12/14/18.
//  Copyright © 2018 AppCoda. All rights reserved.
//

import Foundation
import UIKit

extension UINavigationController {
    
    open override var childForStatusBarStyle: UIViewController? {
        return topViewController
    }
}
